declare module "@americana/diplomat" {
  import type { Map as MaplibreMap, StyleLayer } from "maplibre-gl";

  // MapLibre types expressions as `any`
  type Expression = any;

  export function getLanguageFromURL(url: URL): string | null;

  export function getRelatedLanguageTags(tag: string): string[];

  export function getLocales(): string[];

  export function getLocalizedNameExpression(
    locales: string[],
    options?: {
      includesLegacyFields?: boolean;
      unlocalizedNameProperty?: string;
      localizedNamePropertyFormat?: string;
    },
  ): Expression;

  export function updateVariable(
    letExpr: Expression,
    variable: string,
    value: any,
  ): void;

  export function replacePropertyReferences(
    expression: Expression,
    propertyName: string,
    replacement: any,
  ): Expression | undefined;

  export function listValuesExpression(
    valueList: Expression,
    separator: string | Expression,
    valueToOmit?: Expression,
  ): Expression;

  export function prepareLayer(
    layer: StyleLayer,
    unlocalizedNameProperty?: string,
    glossLocalNames?: boolean,
  ): void;

  export function localizeLayers(
    layers: StyleLayer[],
    locales?: string[],
    options?: {
      unlocalizedNameProperty?: string;
      localizedNamePropertyFormat?: string;
    },
  ): void;

  export function getLocalizedCountryNames(
    locales: string[],
    options?: { uppercase?: boolean },
  ): Record<string, string | undefined>;

  export function getGlobalStateForLocalization(
    locales: string[],
    options?: { uppercaseCountryNames?: boolean },
  ): Record<string, any>;

  export function getLocalizedCountryNameExpression(
    code: Expression,
  ): Expression;

  export function localizeStyle(
    map: MaplibreMap,
    locales?: string[],
    options?: {
      layers?: string[];
      sourceLayers?: string[];
      unlocalizedNameProperty?: string;
      localizedNamePropertyFormat?: string;
      glossLocalNames?: boolean;
      uppercaseCountryNames?: boolean;
    },
  ): void;

  export const localizedName: Expression;
  export const localizedNameInline: Expression;
  export const localizedNameWithLocalGloss: Expression;
}
