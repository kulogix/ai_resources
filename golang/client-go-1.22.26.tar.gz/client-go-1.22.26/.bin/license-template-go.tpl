{{ range . }}
"{{.Name}}","{{.LicenseName}}"
{{- end }}
